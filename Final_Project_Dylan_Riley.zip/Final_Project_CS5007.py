#Sudoku
import numpy as np
import csv 
with open("C:/Users/dylan/OneDrive/Documents/WPI/Intro_Python/SudokuXXX.csv", "r") as sudoku:
    file_read = csv.reader(sudoku)
    listoflists = list(file_read)
#all values separated into list of lists
print(listoflists)

print(np.matrix(listoflists))

listoflists[0] = [0 if i=='' else i for i in listoflists[0]]
listoflists[1] = [0 if i=='' else i for i in listoflists[1]]
listoflists[2] = [0 if i=='' else i for i in listoflists[2]]
listoflists[3] = [0 if i=='' else i for i in listoflists[3]]
listoflists[4] = [0 if i=='' else i for i in listoflists[4]]
listoflists[5] = [0 if i=='' else i for i in listoflists[5]]
listoflists[6] = [0 if i=='' else i for i in listoflists[6]]
listoflists[7] = [0 if i=='' else i for i in listoflists[7]]
listoflists[8] = [0 if i=='' else i for i in listoflists[8]]

print(listoflists[0])

grip = [listoflists[0],
        listoflists[1],
        listoflists[2],
        listoflists[3],
        listoflists[4],
        listoflists[5],
        listoflists[6],
        listoflists[7],
        listoflists[8]]
grid1=[]
grid=[]
for i in grip:
    for n in i:
        grid1.append(int(n))
n=9
for i in range(n):
    grid.append(grid1[i::n])
print(grid1)
print(grid)



def possible(x, y, number):
    global grid
#checking if number in row
    for i in range(0,9):
        if grid[x][i] == number:
            return False

#checking if number in column
    for i in range(0,9):
        if grid[i][y] == number:
            return False
#floor division gives 3 different sections, 0,1,2. 
#needed to mutiple by 3 to get starting point of each grid area. if in grid area 0, then 0 is row start, if 1, then start in row 3.

#starting point of grid horizontal, divides into 3 grid spaces

    section_x = (y // 3) * 3

#starting point of grid vertical

    section_y = (x // 3) * 3

    #row
    for i in range(3):
        #column
        for j in range(3):
#section_y+i gives all 3 rows in each grid, section_x+j gives all 3 sections in column
            if grid[section_y+i][section_x+j] == number:
                return False
    else:
      return True


def solve():
    global grid
    global solved
    for x in range(0,9):
        for y in range(0,9):
            if grid[x][y] == 0:
                for number in range(1,10):
                    if possible(x, y, number):
                        grid[x][y] = number
                        solve()

                        grid[x][y] = 0

                return()
      
    print(np.matrix(grid))
#writes sudoku file back into folder solved. Filename= solved_sudoku_Dylan_R
    np.savetxt('solved_sudoku_Dylan_R.csv', grid, delimiter=',', fmt= '%s')

solve()



#writing the solved sudoku puzzle back into the csv file

""" Was wondering why this doesnt work? Could you leave comment on project.
with open("C:/Users/dylan/OneDrive/Documents/WPI/Intro_Python/SudokuXXX.csv", "r") as sudoku:
   writer= csv.writer(sudoku)
    for i in grid:
        for j in grid:
            sudoku.write(str(j)+',')
        f.write('\n')
#not writable?
"""


